﻿<?php
// Connect to MySQL
$link = mysql_connect( 'your ip :port', 'user', 'pass' );
if ( !$link ) {
  die( 'Could not connect: ' . mysql_error() );
}

// Select the data base
$db = mysql_select_db( 'dbmon', $link );
if ( !$db ) {
  die ( 'Error selecting database \'dbmon\' : ' . mysql_error() );
}

// Fetch the data
$query = "
SELECT round(rows/1000,1) rows,day FROM  ( SELECT rows, DAY  FROM                                                                                         
`mysql_load_statistics`  WHERE HOST='a1-dba-tech01.h' AND PORT =3310  AND DAY -1 < NOW() ORDER BY DAY DESC LIMIT 1440 ) a  ORDER BY DAY";
 
$query1 = "
	SELECT SUM(ROWS)/360000 avg FROM (SELECT ROWS FROM  `mysql_load_statistics`  WHERE HOST='a1-dba-tech01.h' AND PORT =3310  AND DAY -1 < NOW() ORDER BY DAY DESC LIMIT 360) b";


$result = mysql_query( $query );
$result1 = mysql_query( $query1 );
$row1 =  mysql_fetch_assoc( $result1);

// All good?
if ( !$result ) {
  // Nope
  $message  = 'Invalid query: ' . mysql_error() . "\n";
  $message .= 'Whole query: ' . $query;
  die( $message );
}
// Print out rows
// Print out rows
$prefix = '';
echo "[\n";
while ( $row = mysql_fetch_assoc( $result ) ) {
  echo $prefix . " {\n";
  echo '  "category": "' . $row['day'] . '",' . "\n";
  echo '  "value1": ' . $row['rows'] . ',' . "\n";
  echo '  "value2": ' . (int)$row1['avg'] . ',' . "\n"; 
  echo " }";
  $prefix = ",\n";
}
echo "\n]";
// Close the connection
mysql_close($link);
?>
