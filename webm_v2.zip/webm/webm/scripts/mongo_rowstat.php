<?php
$m = new MongoClient( "mongodb://user:pass@ip:port" ); // 连接远程数据库，端口号为指定的端口
$db = $m->local;
$collection = $db->serverstatus;
$cursor= $collection ->find()->fields(array("opcounter"=>true,"sertime"=>true,"_id"=>false))->sort(array('sertime'=>-1))->limit(1001);
$prefix = '';
$tempsort=array();
$tempsort1=array();
$tempsort2=array();
foreach ($cursor as $doc){
	$array = array_values($doc);
	$category = date('Y-m-d H:i',$array[1]->sec);
	$tempsort[$category] = $array[0]['insert'];
	$tempsort1[$category] = $array[0]['update'];
	$tempsort2[$category] = $array[0]['delete'];
}
ksort($tempsort, SORT_STRING);
ksort($tempsort2, SORT_STRING);
ksort($tempsort1, SORT_STRING);
$tempsort=array_merge_recursive($tempsort,$tempsort1,$tempsort2);

$arr = array_values($tempsort);
$arr1 = array_keys($tempsort);

echo "[\n";
for ($x=0; $x<1000; $x++) { 
	echo $prefix . " {\n";
	echo '  "category": "' . $arr1[$x]. '",' . "\n";
	echo '  "value1": ' .($arr[$x+1][0]-$arr[$x][0]) . ','  . "\n"; 
	echo '  "value2": ' .($arr[$x+1][1]-$arr[$x][1]) . ','  . "\n";
	echo '  "value3": ' .($arr[$x+1][2]-$arr[$x][2]) . '' . "\n";
	echo " }";
	$prefix = ",\n";
}
echo "\n]";

?>
