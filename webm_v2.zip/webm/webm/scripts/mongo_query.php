<?php
$m = new MongoClient( "mongodb://user:pass@ip:port" ); // 连接远程数据库，端口号为指定的端口
$db = $m->local;
$collection = $db->serverstatus;
$cursor= $collection ->find()->fields(array("opcounter"=>true,"sertime"=>true,"_id"=>false))->sort(array('sertime'=>-1))->limit(501);
$prefix = '';
$tempsort=array();
$tempsort1=array();
foreach ($cursor as $doc){
	$array = array_values($doc);
		    $category = date('Y-m-d H:i',$array[1]->sec);
		    $tempsort[$category] = $array[0]['query'];
}
ksort($tempsort, SORT_STRING);
$arr = array_values($tempsort);
$arr1 = array_keys($tempsort);
echo "[\n";
for ($x=0; $x<500; $x++) { 
	echo $prefix . " {\n";
	echo '  "category": "' . $arr1[$x]. '",' . "\n";
    echo '  "value1": ' .($arr[$x+1]-$arr[$x]). '' . "\n";
	echo " }";
	$prefix = ",\n";
}
echo "\n]";
?>
