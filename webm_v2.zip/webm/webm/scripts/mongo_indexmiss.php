<?php
$m = new MongoClient( "mongodb://user:pass@ip:port" ); // 连接远程数据库，端口号为指定的端口
$db = $m->local;
$collection = $db->serverstatus;
$cursor= $collection ->find()->fields(array("indexCounters"=>true,"sertime"=>true,"_id"=>false))->sort(array('sertime'=>-1))->limit(501);
$prefix = '';
$tempsort=array();
$tempsort1=array();
foreach ($cursor as $doc){
	    $array = array_values($doc);
		    $category = date('Y-m-d H:i',$array[1]->sec);
		    $tempsort[$category] = $array[0]['misses'];
			    $tempsort1[$category] = $array[0]['missRatio'];
}
ksort($tempsort, SORT_STRING);
ksort($tempsort1, SORT_STRING);
$tempsort=array_merge_recursive($tempsort,$tempsort1);
$arr = array_values($tempsort);
$arr1 = array_keys($tempsort);
echo "[\n";
for ($x=0; $x<500; $x++) { 
	echo $prefix . " {\n";
	echo '  "category": "' . $arr1[$x]. '",' . "\n";
    echo '  "value1": ' .($arr[$x+1][0]-$arr[$x][0]). ',' . "\n";
	echo '  "value2": ' . $arr[$x][1] . ''  . "\n";
	echo " }";
	$prefix = ",\n";
}
echo "\n]";
?>
