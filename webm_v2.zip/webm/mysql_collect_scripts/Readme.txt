user mysqlmon to load statistic to mysql monitor server :




#crontab -l 
30 * * * * sh /usr/local/dbadmin/monitor/slow_query_upload.sh  > /tmp/slowquery.log 2>&1
* * * * * sh  /usr/local/dbadmin/monitor/myawr21_3309.sh  > /tmp/myawr21_3309.log 2>&1
[17:51:39root@a1-dba-tech01 /root]
#ps -ef |grep mysqlmon
root     19504 19379  0 17:51 pts/37   00:00:00 grep mysqlmon
root     41120     1  0 Sep28 ?        00:06:12 /usr/local/dbadmin/monitor/mysqlmon.bin parfile=/usr/local/dbadmin/conf/my3309.cfg
root     41206     1  0 Sep28 ?        00:06:15 /usr/local/dbadmin/monitor/mysqlmon.bin parfile=/usr/local/dbadmin/conf/my3310.cfg
[17:51:46root@a1-dba-tech01 /root]
#cat /usr/local/dbadmin/conf/my3309.cfg
USER=98473bfbb251e10a2525c7cbf18a750f8bcd86335a208bb5bc1cfef9ddf027d7fdabf36519c6a03f6a037eb1a5297eb6
LOAD=8eba347dad047be30ecf67858827ef3af6a38af83693022a6565c393d87da096000c26c369cfac13
log=/tmp/mysql_21_3309.log
wait=10
[17:51:55root@a1-dba-tech01 /root]
#cd /tmp/
[17:52:02root@a1-dba-tech01 /tmp]
#ls
fortify_data.sql  fortify_empty.sql  hsperfdata_root  myawr21_3309.log  mysql_21_3309.log  mysql_21_3310.log  slowquery.log  vgJ9L9g  zabbix_agentd.log  zabbix_agentd.log.old
[17:52:03root@a1-dba-tech01 /tmp]
#tail -f  mysql_21_3310.log
10/14-17:50:53  1.29  0  0  1   367   0   1m   3m   0  0  22   87    4 1565   65  103   54    0 1088  93k    0    0 6147  103   54    0  20k    0  16m 199k    0    0 
www.AnySQL.net -------------------Linux----------------- --------------------------Server-------------------------- ---------------------InnoDB----------------------
10/14-17:51:03  Load SY/WI/US  Free Swp NetI/NetO Err NR Log Sess  Act Exec Cmmt  Ins  Upd  Del  Sel Blog Dump Reco FBuf RowI RowU RowD RowS Disk Writ Redo  Enq Wait
10/14-17:51:03  1.33  0  0  3   355   0   3m  18m   0  0  27  101    5 6889  109  445  599    0 5351   1m    0    0 6146  445  957    0   1m    0  10m   1m    0    0 
10/14-17:51:13  1.44  0  0  4   360   0   3m  11m   0  0  13  100    5 8577  408  675 1484    0 5795 907k    0    0 6145  675 1678    0   7m    0   3m   1m   14    0 
10/14-17:51:23  1.52  0  0  4   360   0   4m  14m   0  0  38  100    6 9238   86  422 1567    0 6827   1m    0    0 6147  422 2146    0   7m    0  79m   1m    0    0 
10/14-17:51:33  1.75  0  0  1   363   0   1m   4m   0  0  11  100    4 2013   92   76  179    1 1426 197k    0    0 6146   76  254    1   1m    0  22m 297k    0    0 
10/14-17:51:43  1.55  0  0  0   362   0 877k   2m   0  0  17   88    4 1494  120   83   47    1  923  89k    0    0 6146   83   47    1 5916    0  12m 172k    0    0 
10/14-17:51:53  1.47  0  0  1   362   0   1m   3m   0  0  20   88    4 1589  209   76   50    0  897  83k    0    0 6145   76   50    0  20k    0  12m 169k    0    0 
10/14-17:52:03  1.62  0  0  1   351   0   1m  10m   0  0  26   99    4 2465  377  390   60    0 1283 198k    0    0 6143  390   60    0  88k    0  14m 497k    0    0 