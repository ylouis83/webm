run mongostat.py to collect statistc to mongodb using json format:

run crontab job :
#crontab -l 
####mongodb_awr_report add by louis liu 
*/1 * * * *  /usr/local/dbadmin/monitor/mongostat.py  >> /storage/sas/mongodb/log/mongostat.log 