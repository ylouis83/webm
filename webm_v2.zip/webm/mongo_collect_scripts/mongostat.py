#!/usr/bin/env python
import pymongo
import os
import operator
from  datetime  import  *
import  time
import getopt
import sys
import bson
import multiprocessing

class DbServerMoitor:
       def __init__(self,conn,locks,indexcount,record,opcounter,mem,iow,load1m,load5m,swapout,swapin,free,us,sys,idle,netin,netout):
          self.conn = conn
          self.locks = locks
          self.indexcount=indexcount
          self.record=record
          self.opcounter=opcounter
          self.mem=mem
          self.iow = iow
          self.load1m = load1m
          self.load5m=load5m
          self.swapin=swapin
          self.swapout=swapout
          self.free=free
          self.us=us    
          self.sys=sys
          self.idle=idle
          self.netin=netin
          self.netout=netout
          

             
serverst = []
dbmons = []

vmstat = os.popen('vmstat -w').readlines()
uptime = os.popen ('cat /proc/loadavg').readlines()
netstat = os.popen('cat /proc/net/dev  |grep "bond0"').readlines()
iostat = os.popen ('iostat').readlines()
split3 = iostat[3].split()
split2 = uptime[0].split()
split1 = vmstat[2].split()
iow = split3[3]
load1m = split2[0]
load5m = split2[1]
swap=split1[2]
free=split1[3]
cwait=split1[15]
netin = netstat[0].split(':')[1].split()[0]
netout = netstat[0].split(':')[1].split()[8]
jiffy = os.sysconf(os.sysconf_names['SC_CLK_TCK'])
num_cpu = multiprocessing.cpu_count()
stat_fd = open('/proc/stat')
swap = os.popen ('cat /proc/vmstat |grep swp').readlines()
netstat = os.popen('cat /proc/net/dev  |grep "bond0"').readlines()
stat_buf = stat_fd.readlines()[0].split()
user, nice, sys, idle, iowait, irq, sirq = ( float(stat_buf[1]), float(stat_buf[2]),
                                            float(stat_buf[3]), float(stat_buf[4]),
                                            float(stat_buf[5]), float(stat_buf[6]),
                                            float(stat_buf[7]) )
swapin,swapout = (swap[0].split()[1], swap[1].split()[1])
netin_n,netout_n = (netstat[0].split(':')[1].split()[0],netstat[0].split(':')[1].split()[8])
stat_fd.close()

time.sleep(1)

stat_fd = open('/proc/stat')
swap = os.popen ('cat /proc/vmstat |grep swp').readlines()
netstat = os.popen('cat /proc/net/dev  |grep "bond0"').readlines()
stat_buf = stat_fd.readlines()[0].split()
user_n, nice_n, sys_n, idle_n, iowait_n, irq_n, sirq_n = ( float(stat_buf[1]), float(stat_buf[2]),
                                                            float(stat_buf[3]), float(stat_buf[4]),
                                                            float(stat_buf[5]), float(stat_buf[6]),
                                                            float(stat_buf[7]) )
swapin_n,swapout_n = (swap[0].split()[1], swap[1].split()[1])
netin_n,netout_n = (netstat[0].split(':')[1].split()[0],netstat[0].split(':')[1].split()[8])
stat_fd.close()


a = ((user_n - user) * 100 / jiffy) / num_cpu
b = ((sys_n - sys)* 100 / jiffy) / num_cpu
c = ((idle_n - idle)* 100 /jiffy) / num_cpu -1
d = int(swapin_n) - int(swapin)
f = int(swapout_n) - int(swapout)
g = int(netin_n) - int(netin)
e = int(netout_n) - int(netout)
us = "%.2f"%a
sys = "%.2f"%b
print c
idle = int("%.0f"%c) 
print idle
swapin = d
swapout = f
netin = g
netout = e
if __name__ == '__main__':
    connection = pymongo.Connection('127.0.0.1',27017)
    dbadmin = connection.admin
    dbadmin.authenticate('liu','liu')
    db=connection.local
    content=db.command(bson.son.SON([('serverStatus',1)]))
    for key in content.keys():
        if key=='connections':
           serverst.append(content[key])
        if key=='locks':
           del content[key]['.']
           serverst.append(content[key])
        if key=='indexCounters':
           serverst.append(content[key])
        if key=='recordStats':
           serverst.append(content[key])
        if key=='opcounters':
           serverst.append(content[key])
        if key=='mem':
           serverst.append(content[key])
    dbmons.append(DbServerMoitor(serverst[0],serverst[1],serverst[4],serverst[2],serverst[5],serverst[3],iow,load1m,load5m,swapin,swapout,free,us,sys,idle,netin,netout))
    a=datetime(*(time.strptime(datetime.now().strftime('%Y-%m-%d %H:%M')+":01",'%Y-%m-%d %H:%M:%S')[0:6]))  
    for temp in dbmons:
        db.serverstatus.insert({"connections":temp.conn,"locks":temp.locks,"indexCounters":temp.indexcount,"recordStats":temp.record,"opcounter":temp.opcounter,"mem":temp.mem,"iowait":temp.iow,"load1m":temp.load1m,"load5m":temp.load5m,"swapout":temp.swapout,"free":temp.free,"us":temp.us,"sys":temp.sys,"idle":temp.idle,"swapin":temp.swapin,"netin":temp.netin,"netout":netout,"sertime":a})

        
    db.logout()
