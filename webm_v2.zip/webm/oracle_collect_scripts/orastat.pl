#!/usr/bin/perl
use strict;
use Getopt::Long;   
use POSIX qw(strftime);    
Getopt::Long::Configure qw(no_ignore_case);    #
use DBI;
use DBI qw(:sql_types);
	
# Don't buffer the output, print as you go
select (STDOUT); $| = 1;
select (STDERR); $| = 1;

my %opt;
my $interval = 2;
my @sys_load;

# Variables For :
#-----> Get SysInfo (from /proc/stat): CPU
my @sys_cpu1 = (0) x 8;
my @sys_cpu2;
my $total_1 = 0;
my $total_2;

my $cpu_not_first = 0;

my $user_diff;
my $system_diff;
my $idle_diff;
my $iowait_diff;

my $user_diff_1;
my $system_diff_1;
my $idle_diff_1;
my $iowait_diff_1;
my $HZ = 100;
#<----- Get SysInfo (from /proc/stat): CPU

#-----> Get SysInfo (from /proc/net/dev): NET
my %net1 = (
	"recv" => 0,
	"send" => 0
);
my $net_not_first = 0;
my %net2;
my $diff_recv;
my $diff_send;
my $net="eth0";
#<----- Get SysInfo (from /proc/net/dev): NET


my %sysstat2 ;
my %sysstat1 ;
my %sysevent2 ;
my %sysevent1 ;
my %sysevent_diff;
my @sysevent_keys;

my $print_not_first = 0;

my $pgcount=0;   
my $snap_time ;

my $tport = 3306;        
my $tuser = "root";
my $tpswd;
my $thost;
my $dbh_save;
my ($Time,$Load,$Logicr,$Bget,$rwrt,$rwrs,$Phyr,$send,$Phyw,$BlkCg,$Logcum,$Logcur,$cget,$CPU,$Redo,$Execs,$HParse,$Parse,$Comit,$Rollbk,$UsCall);
my ($sid,$host);
my $sql;
my $type=1;

my $orastat_header="      Time       Load   Logicr    Cget      Phyr     Phyw    BlkCg Logcum Logcur   CPU    Redo    Execs  HParse  Parse  Comit   Rollbk   UsCall     Bget     rwrt    rwrs     send\n";

&noodba_main();

# ----------------------------------------------------------------------------------------
#  Func : main
# ----------------------------------------------------------------------------------------
sub noodba_main{	
	
	&get_options();


    my $sql;
    $sid=`echo \$ORACLE_SID`;
    chomp($sid);
    $host=`hostname`;
    chomp($host);
    
    if($type==2){
		$dbh_save = &get_connect();
		if(not $dbh_save) {
			exit;
		}
    }
		
	while(1) {

		&print_orastat();
	    $pgcount += 1;		    
	    sleep($interval);
	}	
}



# ----------------------------------------------------------------------------------------
#  Func : print sysstat info
# ----------------------------------------------------------------------------------------
sub print_orastat {
	
    if ( $pgcount%20 == 0 && $type==1) {  
       print $orastat_header;         
     }	
	%sysstat1=%sysstat2;
 		 	
	&get_sysstat();
	&get_loadinfo();
	&get_cpuinfo();
	&get_netinfo();
		
	$snap_time = strftime "%m-%d %H:%M:%S", localtime;

	if($print_not_first){
		$Time=$snap_time;
		$Load=$sys_load[0];
		$Logicr=($sysstat2{"session logical reads"}-$sysstat1{"session logical reads"});
		$Phyr=($sysstat2{"physical reads"}-$sysstat1{"physical reads"});
		$Phyw=($sysstat2{"physical writes"}-$sysstat1{"physical writes"});
		$BlkCg=($sysstat2{"db block changes"}-$sysstat1{"db block changes"});
		$Logcum=$sysstat2{"logons cumulative"}-$sysstat1{"logons cumulative"};
		$Logcur=$sysstat2{"logons current"};
		$CPU=($sysstat2{"CPU used by this session"}-$sysstat1{"CPU used by this session"});
                $Bget=($sysstat2{"db block gets"}-$sysstat1{"db block gets"});
		$Redo=($sysstat2{"redo size"}-$sysstat1{"redo size"});
		$Execs=$sysstat2{"execute count"}-$sysstat1{"execute count"};
		$HParse=$sysstat2{"parse count (hard)"}-$sysstat1{"parse count (hard)"};
                $rwrt=$sysstat2{"redo write time"}-$sysstat1{"redo write time"};
                $rwrs=$sysstat2{"redo synch time"}-$sysstat1{"redo synch time"};
		$Parse=$sysstat2{"parse count (total)"}-$sysstat1{"parse count (total)"};
                $send=$sysstat2{"bytes sent via SQL*Net to client"}-$sysstat1{"bytes sent via SQL*Net to client"};
		$Comit=$sysstat2{"user commits"}-$sysstat1{"user commits"};
		$Rollbk=$sysstat2{"user rollbacks"}-$sysstat1{"user rollbacks"};
		$UsCall=$sysstat2{"user calls"}-$sysstat1{"user calls"};
                $cget=$sysstat2{"consistent gets"}-$sysstat1{"consistent gets"};
		
		if($type==1){
		    printf "%s %5.1f %8.2g %8d %8d %8d %8d %5d %5d  %7s %7s %7d %6d %6d  %6d  %6d  %8d  %8d  %7d  %6d   %7d\n",
		    $snap_time,$sys_load[0],$Logicr,$cget,$Phyr,$Phyw,$BlkCg,$Logcum,
		     $Logcur, int($CPU/100 + 0.5) . "s",
		     int($Redo/1024 + 0.5). "k",
		     $Execs,$HParse,$Parse,$Comit,$Rollbk,$UsCall,$Bget,$rwrt,$rwrs,$send;			
		}elsif($type==2){
			 $sql =	qq{insert into orastat(host,sid,`Load`,cget,Logicr,Phyr,Phyw,BlkCg,Logcum,Logcur,CPU,`Redo`,Execs,HParse,Parse,Comit,Rollbk ,UsCall,bget,rwrt,rwrs,send,`users`,sys,idle ,`wait` ,Netsed ,Netrec) values(\"$host\",\"$sid\",$Load,$cget,$Logicr,$Phyr,$Phyw,$BlkCg,$Logcum,$Logcur,$CPU,$Redo,$Execs,$HParse,$Parse,$Comit,$Rollbk,$UsCall,$Bget,$rwrt,$rwrs,$send,$user_diff_1,$system_diff_1,$idle_diff_1,$iowait_diff_1,$diff_send,$diff_recv)};
			 eval {
				$dbh_save->do($sql);
			 };
			 if( $@ ) {
			 	undef $dbh_save;					
				$dbh_save = &get_connect();
				if(not $dbh_save) {
					exit;
				}
				$dbh_save->do($sql);			     
			  }			
		}	     
	}
     $print_not_first=1;
}


# ----------------------------------------------------------------------------------------
# Func :  print usage
# ----------------------------------------------------------------------------------------
sub print_usage {

	#print BLUE(),BOLD(),<<EOF,RESET();
	print <<EOF;

==========================================================================================
Info  :
        Created By noodba (www.noodba.com) .
   References: orzdba.pl (zhuxu\@taobao.com) ; 
Usage :
Command line options :

   -h,--help           Print Help Info. 
   -i,--interval       Time(second) Interval(default 2).  
   -n,--net            Net  Info(default eth0).
   -t,--type           msg print type(1:stdout;2:save to db)
   --orastat           Oracle load info.
   
   -TP,--tport          Port number to use for  mysql where info is saved (default 3306).
   -tu,--tuser          user name for  mysql where info is saved(default user).
   -tp,--pswd           user password for mysql where info is saved(can't be null).
   -th,--thost          host(ip) for mysql where info is saved(can't be null).  
Sample :
   shell> perl orastat  -i 10 -tp 111111 -th 192.168.1.200 -tu xxxx  -TP 3310  -t 2
==========================================================================================
EOF
	exit;
}

# ----------------------------------------------------------------------------------------
# Func : get options and set option flag
# ----------------------------------------------------------------------------------------
sub get_options {

	# Get options info
	GetOptions(
		\%opt,
		'h|help',          # OUT : print help info
		'i|interval=i',    # IN  : time(second) interval
		'n|net=s',          # IN  : print info
		'tu|tuser=s',      # IN  : user
		'tp|tpswd=s',      # IN  : password
		'th|thost=s',      # IN  : host
		'TP|tport=i',      # IN  : port
		't|type=i',      # IN  : type
									
	) or print_usage();

	if ( !scalar(%opt) ) {
		&print_usage();
	}

	# Handle for options
	$opt{'h'}  and print_usage();
	$opt{'n'}  and $net = $opt{'n'};
	$opt{'i'}  and $interval = $opt{'i'};
	$opt{'tu'} and $tuser = $opt{'tu'};
	$opt{'tp'} and $tpswd = $opt{'tp'};
	$opt{'th'} and $thost = $opt{'th'};
	$opt{'TP'} and $tport = $opt{'TP'};	
	$opt{'t'} and $type = $opt{'t'};				 
	if (
		!(
			
			 defined $tpswd
			and defined $thost
		)
	  )
	{
		&print_usage();
	}
	
}

# ----------------------------------------------------------------------------------------
#  Func : get Load info
# ----------------------------------------------------------------------------------------
sub get_loadinfo {
	open PROC_LOAD, "</proc/loadavg" or die "Can't open file(/proc/loadavg)!";
	if ( defined( my $line = <PROC_LOAD> ) ) {
		chomp($line);
		@sys_load = split( /\s+/, $line );
	}
	close PROC_LOAD or die "Can't close file(/proc/loadavg)!";
}

# ----------------------------------------------------------------------------------------
#  Func : get CPU info
# ----------------------------------------------------------------------------------------
sub get_cpuinfo {
	open PROC_CPU, "</proc/stat" or die "Can't open file(/proc/stat)!";
	if ( defined( my $line = <PROC_CPU> ) )	{
		chomp($line);
		my @sys_cpu2 = split( /\s+/, $line );

		if($cpu_not_first){
			$total_2 =$sys_cpu2[1] +	$sys_cpu2[2] + $sys_cpu2[3] + $sys_cpu2[4] + $sys_cpu2[5] + $sys_cpu2[6] + $sys_cpu2[7];

			$user_diff = $sys_cpu2[1] + $sys_cpu2[2] - $sys_cpu1[1] - $sys_cpu1[2];
			$system_diff = $sys_cpu2[3] + $sys_cpu2[6] + $sys_cpu2[7] - $sys_cpu1[3] - $sys_cpu1[6] - $sys_cpu1[7];
			$idle_diff   = $sys_cpu2[4] - $sys_cpu1[4];
			$iowait_diff = $sys_cpu2[5] - $sys_cpu1[5];

			$user_diff_1 = int( $user_diff / ( $total_2 - $total_1 ) * 100 + 0.5 );
			$system_diff_1 = int( $system_diff / ( $total_2 - $total_1 ) * 100 + 0.5 );
			$idle_diff_1 = int( $idle_diff / ( $total_2 - $total_1 ) * 100 + 0.5 );
			$iowait_diff_1 = int( $iowait_diff / ( $total_2 - $total_1 ) * 100 + 0.5 );
        }
		@sys_cpu1 = @sys_cpu2;
		$total_1  = $total_2;
		$cpu_not_first = 1;
	}
	close PROC_CPU or die "Can't close file(/proc/stat)!";
}


# ----------------------------------------------------------------------------------------
#  Func : get NET info
# ----------------------------------------------------------------------------------------
sub get_netinfo {
	open PROC_NET, "cat /proc/net/dev | grep \"\\b$net\\b\" | "
	  or die "Can't open file(/proc/net/dev)!";
	if ( defined( my $line = <PROC_NET> ) ) {
		chomp($line);
		my @net = split( /\s+|:/, $line );
		%net2 = (
			"recv" => $net[3],
			"send" => $net[11]
		);

		if ($net_not_first) {
			$diff_recv = ($net2{"recv"} - $net1{"recv"});
			$diff_send = ($net2{"send"} - $net1{"send"});
		}

		%net1 = %net2;
		$net_not_first= 1;
	}
	close PROC_NET or die "Can't close file(/proc/net/dev)!";
}


# ----------------------------------------------------------------------------------------
#  Func : get v$sysstat info
# ----------------------------------------------------------------------------------------
sub get_sysstat {
	my $result = `sqlplus -S / as sysdba<<!!
  set echo off
  set colsep ','
  set term off
  set head off
  set feedback off
  SET PAGESIZE 1000
  set linesize 400
  col name for a100
  col value for a200	  
  select name, to_char(value) value from v\\\$sysstat ;
  exit
!!
	  `;
	  
	my $trimline;
	my ($key,$value) ;

    my @result = split( /[\r\n]+/, $result );

 	foreach (@result) {
		chomp($_);
		$trimline=&trim($_);
		#if($trimline ne ""){
	        ($key,$value) = split(/,/,$trimline);
	        $key=&trim($key);
	        $sysstat2{"$key"}=&trim($value);		
			#print "$key:" .$sysstat2{"$key"}. "\n";
		#}
 	}
}


sub trim{
	my $string = shift;
    $string =~ s/^\s+//;
    $string =~ s/\s+$//;
    return $string;
}


sub get_connect{
	return DBI->connect( "DBI:mysql:database=dbmon;host=$thost;port=$tport;mysql_connect_timeout=5","$tuser", "$tpswd", { 'RaiseError' => 1 ,AutoCommit => 1} );
}
