﻿<?php
// Connect to MySQL
$link = mysql_connect( 'ip:port', 'username', 'passwd' );
if ( !$link ) {
  die( 'Could not connect: ' . mysql_error() );
}

// Select the data base
$db = mysql_select_db( 'dbmon', $link );
if ( !$db ) {
  die ( 'Error selecting database \'dbmon\' : ' . mysql_error() );
}

// Fetch the data
$query = "
SELECT  rowi, rowu,day FROM  ( SELECT rowi ,rowu ,DAY  FROM                                                                                         
`mysql_load_statistics`  WHERE HOST='a1-dba-tech01.h' AND PORT =3310  AND DAY -1 < NOW() ORDER BY DAY DESC LIMIT 1440 ) a  ORDER BY DAY";
 
$result = mysql_query( $query );

// All good?
if ( !$result ) {
  // Nope
  $message  = 'Invalid query: ' . mysql_error() . "\n";
  $message .= 'Whole query: ' . $query;
  die( $message );
}
// Print out rows
// Print out rows
$prefix = '';
echo "[\n";
while ( $row = mysql_fetch_assoc( $result ) ) {
  echo $prefix . " {\n";
  echo '  "category": "' . $row['day'] . '",' . "\n";
  echo '  "value1": ' . $row['rowi'] . ',' . "\n";
  echo '  "value2": ' . $row['rowu'] . '' . "\n"; 
  echo " }";
  $prefix = ",\n";
}
echo "\n]";
// Close the connection
mysql_close($link);
?>
